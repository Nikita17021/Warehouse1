﻿using miniProejkt1;
using System;
using System.Collections.Generic;
using System.Linq;

namespace miniProejkt1
{   /*Klasa ItemRepository implementuje interfejs IRepository<Item>*/
    public class ItemRepository : IRepository<Item>
    {
        private readonly List<Item> _items = new();

        public IEnumerable<Item> GetAll() => _items;

        public Item GetById(int id) => _items.FirstOrDefault(i => i.Id == id);

        public void Add(Item item)
        {
            if (_items.Any(i => i.Id == item.Id))
                throw new Exception("Item with the same ID already exists.");
            _items.Add(item);
        }

        public void Update(Item item)
        {
            var existingItem = GetById(item.Id);
            if (existingItem == null)
                throw new Exception("Item not found.");
            existingItem.Name = item.Name;
            existingItem.Quantity = item.Quantity;
        }

        public void Delete(int id)
        {
            var item = GetById(id);
            if (item == null)
                throw new Exception("Item not found.");
            _items.Remove(item);
        }

        public void SetItems(List<Item> items)
        {
            _items.Clear();
            _items.AddRange(items);
        }

    }
}
