﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;


namespace miniProejkt1
{
    public partial class MainForm : Form
    {
        private readonly ItemRepository _itemRepository = new();
        private readonly OrderRepository _orderRepository = new();
        private readonly string _dataFilePath = "inventory_data.json";

        public MainForm()
        {
            InitializeComponent();
            LoadFromFile(); // Загрузка данных из файла при старте
            LoadData();     // Обновление таблицы
        }

        private void LoadFromFile()
        {
            if (File.Exists(_dataFilePath))
            {
                var jsonData = File.ReadAllText(_dataFilePath);
                var items = JsonSerializer.Deserialize<List<Item>>(jsonData);
                if (items != null)
                {
                    _itemRepository.SetItems(items);
                }
            }
        }

        private void SaveToFile()
        {
            var items = _itemRepository.GetAll().ToList();
            var jsonData = JsonSerializer.Serialize(items, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_dataFilePath, jsonData);
        }

        private void LoadData()
        {
            dgvItems.DataSource = _itemRepository.GetAll().ToList();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var item = new Item
            {
                Id = int.Parse(txtId.Text),
                Name = txtName.Text,
                Quantity = int.Parse(txtQuantity.Text)
            };

            try
            {
                _itemRepository.Add(item);
                SaveToFile(); // Сохранение изменений в файл
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Invalid info about item", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSell_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtId.Text, out var id))
            {
                var item = _itemRepository.GetAll().FirstOrDefault(i => i.Id == id);
                if (item == null)
                {
                    MessageBox.Show("Item not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string input = Microsoft.VisualBasic.Interaction.InputBox(
                    "Enter the quantity to sell:",
                    "Sell Quantity",
                    "1");

                if (int.TryParse(input, out var quantityToSell) && quantityToSell > 0)
                {
                    if (item.Quantity >= quantityToSell)
                    {
                        item.Quantity -= quantityToSell; // Уменьшаем количество
                        SaveToFile(); // Сохраняем изменения
                        LoadData();   // Обновляем интерфейс

                        MessageBox.Show($"Sold {quantityToSell} units of {item.Name}.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Not enough stock available.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Invalid quantity entered.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Invalid item ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtId.Text, out var id))
            {
                _itemRepository.Delete(id);
                SaveToFile(); // Сохранение изменений в файл
                LoadData();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var query = txtSearch.Text.ToLower();
            dgvItems.DataSource = _itemRepository.GetAll()
                .Where(i => i.Name.ToLower().Contains(query))
                .ToList();
        }

        private void btnSortByName_Click(object sender, EventArgs e)
        {
            dgvItems.DataSource = _itemRepository.GetAll().OrderBy(i => i.Name).ToList();
        }

        private void btnSortByQuantity_Click(object sender, EventArgs e)
        {
            dgvItems.DataSource = _itemRepository.GetAll().OrderByDescending(i => i.Quantity).ToList();
        }

        private void btnOutOfStock_Click(object sender, EventArgs e)
        {
            dgvItems.DataSource = _itemRepository.GetAll().Where(i => i.Quantity == 0).ToList();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            var outOfStockItems = _itemRepository.GetAll().Where(i => i.Quantity == 0).ToList();
            if (!outOfStockItems.Any())
            {
                MessageBox.Show("All items are in stock.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Запрос количества товаров у пользователя
            string input = Microsoft.VisualBasic.Interaction.InputBox(
                "Enter the quantity to order for out-of-stock items:",
                "Order Quantity",
                "10");

            if (int.TryParse(input, out var quantityToOrder) && quantityToOrder > 0)
            {
                foreach (var item in outOfStockItems)
                {
                    item.Quantity += quantityToOrder; // Добавляем указанное количество
                    _orderRepository.Add(new Order
                    {
                        Id = item.Id,
                        ItemName = item.Name,
                        Quantity = quantityToOrder
                    });
                }

                SaveToFile();
                LoadData();

                MessageBox.Show($"Ordered {quantityToOrder} units for each out-of-stock item.", "Order", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Invalid quantity entered.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveToFile();
            LoadData();
        }
    }
}
