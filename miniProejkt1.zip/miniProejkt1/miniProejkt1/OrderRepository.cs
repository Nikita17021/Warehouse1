using miniProejkt1;
using System.Collections.Generic;

namespace miniProejkt1
{
    public class OrderRepository : IRepository<Order>
    {
        private readonly List<Order> _orders = new();

        public IEnumerable<Order> GetAll() => _orders;

        public Order GetById(int id) => _orders.Find(o => o.Id == id);

        public void Add(Order order)
        {
            _orders.Add(order);
        }

        public void Update(Order order)
        {
            var existingOrder = GetById(order.Id);
            if (existingOrder != null)
            {
                existingOrder.ItemName = order.ItemName;
                existingOrder.Quantity = order.Quantity;
            }
        }

        public void Delete(int id)
        {
            var order = GetById(id);
            if (order != null)
            {
                _orders.Remove(order);
            }
        }
    }
}
