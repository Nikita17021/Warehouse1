﻿namespace miniProejkt1
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvItems;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSortByName;
        private System.Windows.Forms.Button btnSortByQuantity;
        private System.Windows.Forms.Button btnOutOfStock;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnSell;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnSell = new Button();
            dgvItems = new DataGridView();
            txtId = new TextBox();
            txtName = new TextBox();
            txtQuantity = new TextBox();
            btnAdd = new Button();
            btnDelete = new Button();
            btnSearch = new Button();
            txtSearch = new TextBox();
            btnSortByName = new Button();
            btnSortByQuantity = new Button();
            btnOutOfStock = new Button();
            btnOrder = new Button();
            btnSave = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvItems).BeginInit();
            SuspendLayout();
            // 
            // btnSell
            // 
            btnSell.Location = new Point(523, 235);
            btnSell.Name = "btnSell";
            btnSell.Size = new Size(100, 30);
            btnSell.TabIndex = 6;
            btnSell.Text = "Sell";
            btnSell.UseVisualStyleBackColor = true;
            btnSell.Click += btnSell_Click;
            // 
            // dgvItems
            // 
            dgvItems.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvItems.Location = new Point(12, 12);
            dgvItems.Name = "dgvItems";
            dgvItems.RowHeadersWidth = 62;
            dgvItems.Size = new Size(600, 200);
            dgvItems.TabIndex = 0;
            // 
            // txtId
            // 
            txtId.Location = new Point(12, 230);
            txtId.Name = "txtId";
            txtId.Size = new Size(50, 31);
            txtId.TabIndex = 1;
            // 
            // txtName
            // 
            txtName.Location = new Point(80, 230);
            txtName.Name = "txtName";
            txtName.Size = new Size(150, 31);
            txtName.TabIndex = 2;
            // 
            // txtQuantity
            // 
            txtQuantity.Location = new Point(250, 230);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(60, 31);
            txtQuantity.TabIndex = 3;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(331, 226);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(84, 39);
            btnAdd.TabIndex = 4;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(433, 230);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(84, 37);
            btnDelete.TabIndex = 5;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(843, 402);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(84, 40);
            btnSearch.TabIndex = 6;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(478, 407);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(344, 31);
            txtSearch.TabIndex = 7;
            // 
            // btnSortByName
            // 
            btnSortByName.Location = new Point(742, 12);
            btnSortByName.Name = "btnSortByName";
            btnSortByName.Size = new Size(204, 31);
            btnSortByName.TabIndex = 8;
            btnSortByName.Text = "Sort by Name";
            btnSortByName.UseVisualStyleBackColor = true;
            btnSortByName.Click += btnSortByName_Click;
            // 
            // btnSortByQuantity
            // 
            btnSortByQuantity.Location = new Point(742, 49);
            btnSortByQuantity.Name = "btnSortByQuantity";
            btnSortByQuantity.Size = new Size(204, 40);
            btnSortByQuantity.TabIndex = 9;
            btnSortByQuantity.Text = "Sort by Quantity";
            btnSortByQuantity.UseVisualStyleBackColor = true;
            btnSortByQuantity.Click += btnSortByQuantity_Click;
            // 
            // btnOutOfStock
            // 
            btnOutOfStock.Location = new Point(618, 12);
            btnOutOfStock.Name = "btnOutOfStock";
            btnOutOfStock.Size = new Size(120, 45);
            btnOutOfStock.TabIndex = 10;
            btnOutOfStock.Text = "Out of Stock";
            btnOutOfStock.UseVisualStyleBackColor = true;
            btnOutOfStock.Click += btnOutOfStock_Click;
            // 
            // btnOrder
            // 
            btnOrder.Location = new Point(618, 63);
            btnOrder.Name = "btnOrder";
            btnOrder.Size = new Size(100, 34);
            btnOrder.TabIndex = 11;
            btnOrder.Text = "Order Items";
            btnOrder.UseVisualStyleBackColor = true;
            btnOrder.Click += btnOrder_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(12, 407);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(204, 40);
            btnSave.TabIndex = 10;
            btnSave.Text = "Save info";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // MainForm
            // 
            ClientSize = new Size(1049, 628);
            Controls.Add(btnOrder);
            Controls.Add(btnOutOfStock);
            Controls.Add(btnSortByQuantity);
            Controls.Add(btnSortByName);
            Controls.Add(txtSearch);
            Controls.Add(btnSearch);
            Controls.Add(btnDelete);
            Controls.Add(btnAdd);
            Controls.Add(txtQuantity);
            Controls.Add(txtName);
            Controls.Add(txtId);
            Controls.Add(dgvItems);
            Controls.Add(btnSave);
            Controls.Add(btnSell);
            Name = "MainForm";
            Text = "Inventory Management";
            ((System.ComponentModel.ISupportInitialize)dgvItems).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
